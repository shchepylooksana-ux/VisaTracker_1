include ':app'
rootProject.name = "VisaTracker"
